Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/take-screenshot-of-webpage-with-html2canvas/

